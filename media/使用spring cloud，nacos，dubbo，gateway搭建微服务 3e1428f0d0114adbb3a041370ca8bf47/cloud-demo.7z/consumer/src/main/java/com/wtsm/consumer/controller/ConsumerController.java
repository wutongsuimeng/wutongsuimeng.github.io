package com.wtsm.consumer.controller;

import com.wtsm.providerapi.IProviderService;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class ConsumerController {

    @DubboReference
    private IProviderService providerService;

    @GetMapping("/getProvider")
    public String getProvider(){
        return providerService.getProvider();
    }
}
