package com.wtsm.providerapi;


public interface IProviderService {
    String getProvider();
}
