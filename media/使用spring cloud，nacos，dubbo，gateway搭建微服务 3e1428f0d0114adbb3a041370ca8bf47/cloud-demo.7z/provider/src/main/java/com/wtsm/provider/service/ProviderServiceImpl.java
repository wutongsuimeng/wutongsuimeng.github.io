package com.wtsm.provider.service;

import com.wtsm.providerapi.IProviderService;
import org.apache.dubbo.config.annotation.DubboService;

@DubboService
public class ProviderServiceImpl implements IProviderService {
    @Override
    public String getProvider() {
        return "调用服务成功";
    }
}
